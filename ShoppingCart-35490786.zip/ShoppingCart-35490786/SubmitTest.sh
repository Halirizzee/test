read -p "Enter your Employee ID : " empid
read -p "Enter your token : " token
echo "Please checkin, commit and push your code to Master branch of your repo; You have to login to LMS and then submit your code. Your code will be submitted manually by you. This is important and if you dont submit it then it will not be evaluated."
sleep 5s
read -n 1 -s
