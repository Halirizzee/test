import React from 'react';
import { Router, Route, Switch } from 'react-router-dom';
// import {LoginPage} from '../LoginPage';
import { history } from '../_helpers';
import { ProductsAPI} from '../Services';
import { HomePage } from '../HomePage';
// import { CheckOut } from '../CheckOut';
// import { Order } from '../Order';

class App extends React.Component {
 
login(){
    // history.push("/dist_xxxxx/login");
}
    render() {
        
        var body_styles = {
            
            
            fontWeight:'bold'
        };
        var heading_style = {
            position: 'relative',
            left: '25%',
            top: '20%',
            color : 'grey'
        }
        console.log("env " + JSON.stringify( process.env));
        return (<div className='container' style={{position: 'relative', height: '100%', width: '100%'}}>
            {console.log("env " + JSON.stringify( process.env))}
        <div className='test'>
        <div className="head" style={{backgroundColor: 'rgb(114, 222, 255)'}}><div className='heading' style={{height: '50px'}} ><h3 id='title' style={heading_style}>Welcome Shop Easy Offer Zone Top Deals & Discounts</h3></div></div>
           <button style={{}} className='btn btn-primary' id='signinButton' onClick={this.login}>Sign In</button> <div className='router' style={{height:'100%', width:'100%'}}>
            <Router history={history} basename='/dist_xxxxx'>
                            <div>
                                <Switch>
                                <Route exact path={"/"} component={HomePage} />
                                <Route exact path={"/dist_xxxxx/"} component={HomePage} />
                                {/* <Route path={"/dist_xxxxx/login"} component={LoginPage} />
                                <Route path={"/dist_xxxxx/checkout"} component={CheckOut} />
                                <Route path={"/dist_xxxxx/order"} component={Order} />
                   */}
                                </Switch>
                                </div>
                        </Router>
            {/* 
             
  <button onClick={this.login}>SignIn</button></div>
                <div className='testing' style={body_styles}><ProductsAPI/></div>
                </div>   
               
                </div> */}</div></div></div>
        );
    }
}


 export { App as App }; 