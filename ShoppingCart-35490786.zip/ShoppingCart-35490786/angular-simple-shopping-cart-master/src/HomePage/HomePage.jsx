import React from 'react';
import { history } from '../_helpers';
import { ProductsAPI} from '../Services';
class HomePage extends React.Component{
    
    render(){
        return (
        <div className='body' style={{height: '100%', width: '100%'}}>
        <div className='content' style={{width: "65%"}}><ProductsAPI/></div></div>
        );    
}
}
export{HomePage as HomePage}